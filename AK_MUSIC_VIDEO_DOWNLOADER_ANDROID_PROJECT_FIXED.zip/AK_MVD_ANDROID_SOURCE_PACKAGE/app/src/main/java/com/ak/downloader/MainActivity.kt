package com.ak.downloader
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,28,24,20); setBackgroundColor(0xFF101820.toInt()) }
        page.addView(TextView(this).apply { text = "AK MUSIC & VIDEO DOWNLOADER"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(-1) }, params())
        page.addView(TextView(this).apply { text = "Android Edition • ஆரம்ப பதிப்பு"; gravity = Gravity.CENTER; setTextColor(0xFFB8C7D1.toInt()); setPadding(0,8,0,20) }, params())
        page.addView(Button(this).apply {
            text = "மொபைலில் உள்ள பாடல் / வீடியோவைத் தேர்வு செய்"; isAllCaps = false
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*","video/*")) }
                startActivityForResult(i, PICK_MEDIA)
            }
        }, params())
        status = TextView(this).apply { text = "தேர்ந்தெடுத்த மீடியா இங்கே இயக்கப்படும்."; setTextColor(0xFFD9E2E8.toInt()); setPadding(0,16,0,12) }
        page.addView(status, params())
        playerView = PlayerView(this).apply { useController = true }
        page.addView(playerView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,230))
        page.addView(TextView(this).apply { text = "\nஅடுத்த கட்டங்களில் அனுமதிக்கப்பட்ட மூலங்களிலிருந்து தேடல்/பதிவிறக்கம், பதிவிறக்கப் பட்டியல், மாற்றி, தமிழ்–ஆங்கில அமைப்புகள் சேர்க்கப்படும்."; setTextColor(0xFFB8C7D1.toInt()) }, params())
        setContentView(page)
    }
    private fun params() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == PICK_MEDIA && resultCode == RESULT_OK) {
            val uri:Uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_:Exception) {}
            player?.release()
            player = ExoPlayer.Builder(this).build().also { exo -> playerView.player=exo; exo.setMediaItem(MediaItem.fromUri(uri)); exo.prepare(); exo.playWhenReady=true }
            status.text = "இப்போது இயக்கப்படுகிறது: ${uri.lastPathSegment ?: "தேர்ந்தெடுத்த கோப்பு"}"
        }
    }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { playerView.player=null; player?.release(); player=null; super.onDestroy() }
    companion object { private const val PICK_MEDIA=1001 }
}
