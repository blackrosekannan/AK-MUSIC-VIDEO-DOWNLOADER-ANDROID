plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.ak.downloader"; compileSdk = 36; defaultConfig { applicationId = "com.ak.downloader"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0.0" } }
dependencies { implementation("androidx.appcompat:appcompat:1.7.1"); implementation("androidx.media3:media3-exoplayer:1.5.1"); implementation("androidx.media3:media3-ui:1.5.1") }
