# AK MUSIC & VIDEO DOWNLOADER — Android project

இது APK உருவாக்குவதற்கான ஆரம்ப Android project.

## ஆரம்ப பதிப்பில்
- Android செயலி அடிப்படை அமைப்பு
- மொபைலில் உள்ள audio/video கோப்பைத் தேர்வு செய்தல்
- Media3 player மூலம் கோப்பை இயக்குதல்
- GitHub Actions மூலம் Debug APK உருவாக்குதல்

## APK உருவாக்கும் முறை
1. இந்த ZIP-ஐ GitHub-ல் புதிய repository-க்கு upload செய்யவும்.
2. Repository-யில் Actions tab திறக்கவும்.
3. `Build AK Downloader APK` workflow-ஐத் தேர்வு செய்து `Run workflow` அழுத்தவும்.
4. Build முடிந்ததும் Artifacts பகுதியில் APK ZIP-ஐப் பதிவிறக்கவும்.
5. ZIP-ஐ extract செய்து APK-ஐ Android-ல் நிறுவவும்.

## குறிப்பு
இது முழுமையான downloader அல்ல; ஆரம்ப native foundation மட்டுமே. அடுத்த கட்டங்களில் அனுமதிக்கப்பட்ட/நேரடி media sources, download manager, history, search, converter ஆகியவை சேர்க்கப்பட்டு சோதிக்கப்படும். YouTube உள்ளிட்ட சேவைகளின் DRM அல்லது பாதுகாப்புக் கட்டுப்பாடுகளை மீறாது.
